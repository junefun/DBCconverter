﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBC2Excel
{
    public class ExcelBE
    {
        private int _row = 0;
        private int _col = 0;
        private string _text = string.Empty;
        private string _startCell = string.Empty;
        private string _endCell = string.Empty;
        private string _interiorColor = string.Empty;
        private bool _isMerge = false;
        private int _size = 0;
        private string _fontColor = string.Empty;
        private string _format = string.Empty;

        public ExcelBE(int row, int col, string text, string startCell, string endCell, string interiorColor, bool isMerge, int size, string fontColor, string format)
        {
            _row = row;
            _col = col;
            _text = text;
            _startCell = startCell;
            _endCell = endCell;
            _interiorColor = interiorColor;
            _isMerge = isMerge;
            _size = size;
            _fontColor = fontColor;
            _format = format;
        }

        public ExcelBE()
        { }

        public int Row
        {
            get { return _row; }
            set { _row = value; }
        }

        public int Col
        {
            get { return _col; }
            set { _col = value; }
        }

        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }

        public string StartCell
        {
            get { return _startCell; }
            set { _startCell = value; }
        }

        public string EndCell
        {
            get { return _endCell; }
            set { _endCell = value; }
        }

        public string InteriorColor
        {
            get { return _interiorColor; }
            set { _interiorColor = value; }
        }

        public bool IsMerge
        {
            get { return _isMerge; }
            set { _isMerge = value; }
        }

        public int Size
        {
            get { return _size; }
            set { _size = value; }
        }

        public string FontColor
        {
            get { return _fontColor; }
            set { _fontColor = value; }
        }

        public string Formart
        {
            get { return _format; }
            set { _format = value; }
        }

    }

    public class ExcelBase
    {
        private Microsoft.Office.Interop.Excel.Application app = null;
        private Microsoft.Office.Interop.Excel.Workbook workbook = null;
        private Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
        private Microsoft.Office.Interop.Excel.Range workSheet_range = null;
        public Dictionary<string, int> ExcelDic;
        private List<string> listCurrentRow;
        public ExcelBase()
        {
            //createDoc();
            ExcelDic = new Dictionary<string, int>();
            ExcelDic.Add("A", 1);
            ExcelDic.Add("B", 2);
            ExcelDic.Add("C", 3);
            ExcelDic.Add("D", 4);
            ExcelDic.Add("E", 5);
            ExcelDic.Add("F", 6);
            ExcelDic.Add("G", 7);
            ExcelDic.Add("H", 8);
            ExcelDic.Add("I", 9);
            ExcelDic.Add("J", 10);
            ExcelDic.Add("K", 11);
            ExcelDic.Add("L", 12);
            ExcelDic.Add("M", 13);
            ExcelDic.Add("N", 14);
            ExcelDic.Add("O", 15);
            ExcelDic.Add("P", 16);
            ExcelDic.Add("Q", 17);
            ExcelDic.Add("R", 18);
            ExcelDic.Add("S", 19);
            ExcelDic.Add("T", 20);
            ExcelDic.Add("U", 21);
            ExcelDic.Add("V", 22);
            ExcelDic.Add("W", 23);
            ExcelDic.Add("X", 24);
            ExcelDic.Add("Y", 25);
            ExcelDic.Add("Z", 26);
            listCurrentRow = new List<string>();



        }
        public ExcelBase(string path,int sheetnum)
        {
            openExcel( path, sheetnum);
        }
        public void saveExcel(string path)
        {
            workbook.Saved = true;

            workbook.SaveCopyAs(path);
        }


        public void openExcel(string path,int sheetnnum)
        {
            app = new Microsoft.Office.Interop.Excel.Application();
            app.Visible = false;
            workbook = app.Workbooks.Open(path);
            worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[sheetnnum];
        }
        public void openExcel(string path)
        {
            app = new Microsoft.Office.Interop.Excel.Application();
            app.Visible = false;
            workbook = app.Workbooks.Open(path);
            worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];
        }
        public void openExcel(string path,bool visable)
        {
            app = new Microsoft.Office.Interop.Excel.Application();
            app.Visible = visable;
            workbook = app.Workbooks.Open(path);
           
        }
        public void openExcel(string path, string sheetname)
        {
            app = new Microsoft.Office.Interop.Excel.Application();
            app.Visible = false;
            workbook = app.Workbooks.Open(path);
            worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[sheetname];
        }

        public void createDoc()
        {
            try
            {
                app = new Microsoft.Office.Interop.Excel.Application();
                app.Visible = true;
                workbook = app.Workbooks.Add(1);
                worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];
            }
            catch (Exception ex)
            {
                Console.Write("Error");
            }
            finally
            {
            }
        }
        public int RowCount()
        {
           return worksheet.Rows.Count;
        }
        public List<string> ReadRow(string start,string end)
        {
           Range aa= worksheet.Cells.get_Range(start, end);
            object[,] arryItem = (object[,])aa.Value2;
            int s=arryItem.Length;
            listCurrentRow.Clear();

            for (int i = 0; i < s; i++)
            {

                listCurrentRow.Add(arryItem[1, i + 1]!=null? arryItem[1, i + 1].ToString():"NULL");
            }

            return listCurrentRow;
        }

        public string GetValue(string columtag)
        {
            return listCurrentRow[ExcelDic[columtag.ToUpper()]-1];

        }
        public string GetValue(int columindex)
        {
            return listCurrentRow[columindex - 1];

        }

        public void CloseExcel()
        {
            workbook.Close();
            app.Quit();
        }
        public string ReadCell(int rowindex,int columindex)
        {
            string temp = ((Range)worksheet.Cells[rowindex, columindex]).Text.ToString();
            
            return temp;
        }
        public string ReadCell(string cellposition)
        {
            string temp = ((Range)worksheet.Range[cellposition]).Text.ToString();

            return temp;
        }


        public void InsertData(ExcelBE be)
        {
            worksheet.Cells[be.Row, be.Col] = be.Text;
            workSheet_range = worksheet.get_Range(be.StartCell, be.EndCell);
            workSheet_range.MergeCells = be.IsMerge;
            workSheet_range.Interior.Color = GetColorValue(be.InteriorColor);
            workSheet_range.Borders.Color = System.Drawing.Color.Black.ToArgb();
            workSheet_range.ColumnWidth = be.Size;
            workSheet_range.Font.Color = string.IsNullOrEmpty(be.FontColor) ? System.Drawing.Color.White.ToArgb() : System.Drawing.Color.Black.ToArgb();
            workSheet_range.NumberFormat = be.Formart;
            workSheet_range.RowHeight = 30;
            workSheet_range.Font.Size = 13;
           
            workSheet_range.Font.Name = "Microsoft YaHei UI";
        }

        private int GetColorValue(string interiorColor)
        {
            switch (interiorColor)
            {
                case "YELLOW":
                    return System.Drawing.Color.Yellow.ToArgb();
                case "GRAY":
                    return System.Drawing.Color.Gray.ToArgb();
                case "GAINSBORO":
                    return System.Drawing.Color.Gainsboro.ToArgb();
                case "Turquoise":
                    return System.Drawing.Color.Turquoise.ToArgb();
                case "PeachPuff":
                    return System.Drawing.Color.PeachPuff.ToArgb();

                default:
                    return System.Drawing.Color.White.ToArgb();
            }
        }
    }

}
