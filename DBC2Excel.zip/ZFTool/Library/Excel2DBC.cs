﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBC2Excel
{
    class Excel2DBC
    {


        Dictionary<string, string> gDic;
        public List<Message> lisMsg { get; set; }
        public string readLine { get; set; }

        private string DBC_Header_Templete = "VERSION \"\"";
private string header2=@"

NS_ : 
	NS_DESC_
	CM_
	BA_DEF_
	BA_
	VAL_
	CAT_DEF_
	CAT_
	FILTER
	BA_DEF_DEF_
	EV_DATA_
	ENVVAR_DATA_
	SGTYPE_
	SGTYPE_VAL_
	BA_DEF_SGTYPE_
	BA_SGTYPE_
	SIG_TYPE_REF_
	VAL_TABLE_
	SIG_GROUP_
	SIG_VALTYPE_
	SIGTYPE_VALTYPE_
	BO_TX_BU_
	BA_DEF_REL_
	BA_REL_
	BA_DEF_DEF_REL_
	BU_SG_REL_
	BU_EV_REL_
	BU_BO_REL_
	SG_MUL_VAL_

BS_:";

        private string DBC_Node_Templete = "\nBU_: #NODENAME#\n";
        private string DBC_Message_Templete = "BO_ #MESSAGE#\n";
        private string DBC_Signal_Templete = " SG_ #SIGNAL#\n";
        private string DBC_CommantMsg_Templete = "CM_ BO_ #COMMANT#\";\n";
        private string DBC_CommantSig_Templete = "CM_ SG_ #COMMANT#\";\n";
        private string DBC_Cycletime_Templete = "BA_ \"GenMsgDelayTime\" BO_ #Delaytime#;\nBA_ \"GenMsgSendType\" BO_ #SendType#;\nBA_ \"GenMsgCycleTime\" BO_ #Cycletime#;\n";
        private string DBC_ValTabSig_Templete = "VAL_ #VALUETABLE#\n";
        private string DBC_Templete;

        private ExcelBase excel;
        public Dictionary<string, string> msgMarkDic;
        public List<string> ListMsgfields { get; set; }

        public List<string> listCommantStr { get; set; }
        public List<string> listCyclTimeStr { get; set; }
        public List<string> listValStr { get; set; }
        public List<string> listMsgStr { get; set; }
        public string NodeStr { get; set; }
        public Excel2DBC()
        {
            DBC_Header_Templete = DBC_Header_Templete + header2;
               DBC_Templete = DBC_Header_Templete + DBC_Node_Templete +
                            DBC_Message_Templete + DBC_Signal_Templete + 
                            DBC_CommantMsg_Templete + DBC_CommantSig_Templete + DBC_Cycletime_Templete+DBC_ValTabSig_Templete;

            lisMsg = new List<Message>();

            listMsgStr = new List<string>();
            listValStr = new List<string>();
            listCommantStr = new List<string>();
            listCyclTimeStr = new List<string>();
            NodeStr = "BU_: ";
            gDic = new Dictionary<string, string>();
            gDic.Add("Motorola", "0");
            gDic.Add("Intel", "1");
            gDic.Add("Unsigned", "+");
            gDic.Add("Signed", "-");

            msgMarkDic = new Dictionary<string, string>();
            excel = new ExcelBase();
            ListMsgfields = new List<string>();
            ListMsgfields.Add("MsgID");
            ListMsgfields.Add("MsgName");
            ListMsgfields.Add("MsgType");
            ListMsgfields.Add("Cycletime");
            ListMsgfields.Add("DLC");
            ListMsgfields.Add("Transmiter");
            ListMsgfields.Add("Receiver");
            ListMsgfields.Add("Commants");
            ListMsgfields.Add("SigName");
            ListMsgfields.Add("StartBit");
            ListMsgfields.Add("Length");
            ListMsgfields.Add("ByteOrder");
            ListMsgfields.Add("ValueType");
            ListMsgfields.Add("InitialValue");
            ListMsgfields.Add("Factor");
            ListMsgfields.Add("Offset");
            ListMsgfields.Add("Minimum");
            ListMsgfields.Add("Maximum");
            ListMsgfields.Add("ValueTable");
        }



        public string NodeGen()
        {
            List<string> listNode = new List<string>();
            for (int i = 0; i < lisMsg.Count; i++)
            {
                if (!listNode.Contains(lisMsg[i].Transmiter.Trim()))
                {
                    listNode.Add(lisMsg[i].Transmiter.Trim());
                }
                for (int j = 0; j < lisMsg[i].Signals.Count; j++)
                {
                    string[] temp = lisMsg[i].Signals[j].Receiver.Split(',');
                    for (int k = 0; k < temp.Length; k++)
                    {
                        if (!listNode.Contains(temp[k].Trim()))
                        {
                            listNode.Add(temp[k].Trim());
                        }
                    }
                }
                
            }
            string nodestring = "";
            if (listNode.Count > 0)
            {
                foreach (var item in listNode)
                {
                    nodestring = nodestring + item+" ";
                }
            }
            NodeStr= DBC_Node_Templete.Replace("#NODENAME#", nodestring.Replace("Vector__XXX", ""));
            return NodeStr;
        }

        public List<string> MessgaeGen()
        {
            
            for (int i = 0; i < lisMsg.Count; i++)
            { string tempid = "3221225472";
                if (lisMsg[i].MsgID.Trim() == "FFFFFFFF")
                {
                    tempid = "3221225472";
                }
                else
                {
                    tempid = Convert.ToUInt32(lisMsg[i].MsgID.Trim(), 16).ToString();
                }

                listCommantStr.Add(DBC_CommantMsg_Templete.Replace("#COMMANT#",tempid.Trim()+" \""+lisMsg[i].Commants.Trim()));
                if (lisMsg[i].Cycletime.Trim() != "NULL")
                {
                    listCyclTimeStr.Add(DBC_Cycletime_Templete.Replace("#Cycletime#", tempid.Trim() + " " + lisMsg[i].Cycletime.Trim()).Replace("#Delaytime#", tempid + " " + lisMsg[i].Delaytime.Trim()).Replace("#SendType#", tempid + " " + lisMsg[i].SendType));
                }


                string temp = tempid + " "+ lisMsg[i].MsgName.Trim() + ": "+ lisMsg[i].DLC.Trim() + " "+ lisMsg[i].Transmiter.Trim();
                listMsgStr.Add(DBC_Message_Templete.Replace("#MESSAGE#", temp));
                foreach(var item in lisMsg[i].Signals)
                {
                    string tempsig = item.SigName.Trim() + " : " + item.StartBit.Trim() + "|" + item.Length.Trim() + "@" + gDic[item.ByteOrder].Trim() + gDic[item.ValueType].Trim()
                                    + " (" + item.Factor.Trim() + "," + item.Offset.Trim() + ") [" + item.Minimum.Trim() + "|" + item.Maximum.Trim() + "] \"" + item.Unit.Trim() + "\" " + item.Receiver.Trim();
                    string sigtemp = DBC_Signal_Templete.Replace("#SIGNAL#", tempsig);
                    listMsgStr[listMsgStr.Count - 1] = listMsgStr[listMsgStr.Count - 1] + sigtemp;
                    string signame;
                    if (item.SigName.Contains(" "))
                    {
                        signame=item.SigName.Split(' ')[0];
                    }
                    else
                    {

                        signame = item.SigName;
                    }
                    listCommantStr.Add(DBC_CommantSig_Templete.Replace("#COMMANT#", tempid + " "+signame+" \""+ item.Commants));
                    if (item.ValueTable.Trim() != "NULL")
                    {
                        string Valuetable = tempid + " " + signame + " " + item.ValueTable.Trim();
                        listValStr.Add(DBC_ValTabSig_Templete.Replace("#VALUETABLE#", Valuetable));
                    }
                    

                }
            }
            return listMsgStr;
        }
        /// <summary>
        /// default the sheet NO. =1
        /// </summary>
        /// <param name="path"></param>
        public int ReadExcel(string path,string rowstart,string rowend)
        {
            // step read a row
            excel.openExcel(path);
            List<string> temprow = new List<string>();
            int index = 3;
            while (true)
            {

                temprow = excel.ReadRow(rowstart+index.ToString(), rowend + index.ToString());
                //judge if the message ID is NULL? if not null ,then add a new message
                if (temprow[(excel.ExcelDic[msgMarkDic["MsgID"]]) - 1] != "NULL")
                {
                    lisMsg.Add(new Message()
                    {
                        MsgID = temprow[(excel.ExcelDic[msgMarkDic["MsgID"]]) - 1],
                        MsgName = temprow[(excel.ExcelDic[msgMarkDic["MsgName"]]) - 1],
                        MsgType = temprow[(excel.ExcelDic[msgMarkDic["MsgType"]]) - 1],
                        Cycletime = temprow[(excel.ExcelDic[msgMarkDic["Cycletime"]]) - 1],
                        SendType = temprow[(excel.ExcelDic[msgMarkDic["SendType"]]) - 1],
                        Delaytime = temprow[(excel.ExcelDic[msgMarkDic["Delaytime"]]) - 1],
                        DLC = temprow[(excel.ExcelDic[msgMarkDic["DLC"]]) - 1],
                        Transmiter = temprow[(excel.ExcelDic[msgMarkDic["Transmiter"]]) - 1],
                        Receiver = temprow[(excel.ExcelDic[msgMarkDic["Receiver"]]) - 1],
                        Commants = temprow[(excel.ExcelDic[msgMarkDic["Commants"]]) - 1],
                        Signals = new List<Signal>()
                    }

                    );
                }
                else if (temprow[(excel.ExcelDic[msgMarkDic["SigName"]]) - 1] != "NULL")
                {
                    lisMsg[lisMsg.Count - 1].Signals.Add(new Signal()
                    {
                        SigName = temprow[(excel.ExcelDic[msgMarkDic["SigName"]]) - 1],
                        StartBit = temprow[(excel.ExcelDic[msgMarkDic["StartBit"]]) - 1],
                        Length = temprow[(excel.ExcelDic[msgMarkDic["Length"]]) - 1],
                        ByteOrder = temprow[(excel.ExcelDic[msgMarkDic["ByteOrder"]]) - 1],
                        ValueType = temprow[(excel.ExcelDic[msgMarkDic["ValueType"]]) - 1],
                        Unit = temprow[(excel.ExcelDic[msgMarkDic["Unit"]]) - 1],
                        InitialValue = temprow[(excel.ExcelDic[msgMarkDic["InitialValue"]]) - 1],
                        Factor = temprow[(excel.ExcelDic[msgMarkDic["Factor"]]) - 1],
                        Offset = temprow[(excel.ExcelDic[msgMarkDic["Offset"]]) - 1],
                        Minimum = temprow[(excel.ExcelDic[msgMarkDic["Minimum"]]) - 1],
                        Maximum = temprow[(excel.ExcelDic[msgMarkDic["Maximum"]]) - 1],
                        Transmiter = temprow[(excel.ExcelDic[msgMarkDic["Transmiter"]]) - 1],
                        Receiver = temprow[(excel.ExcelDic[msgMarkDic["Receiver"]]) - 1],
                        Commants = temprow[(excel.ExcelDic[msgMarkDic["Commants"]]) - 1],
                        ValueTable = temprow[(excel.ExcelDic[msgMarkDic["ValueTable"]]) - 1],

                    });
                }
                else
                {
                    break;
                }
                index++;

            }
            excel.CloseExcel();
            return index;
           

        }


        public void GenDic(string key,string value)
        {
            

            msgMarkDic.Add(key, value);
            //msgMarkDic.Add("MsgID","A");
            //msgMarkDic.Add("MsgName", "B");
            //msgMarkDic.Add("MsgType", "C");
            //msgMarkDic.Add("Cycletime", "D");
            //msgMarkDic.Add("Delaytime", "F");
            //msgMarkDic.Add("SendType", "E");
            //msgMarkDic.Add("DLC", "G");
            //msgMarkDic.Add("Transmiter", "T");
            //msgMarkDic.Add("Receiver", "U");
            //msgMarkDic.Add("Commants", "V");
            //msgMarkDic.Add("SigName", "H");
            //msgMarkDic.Add("StartBit", "I");
            //msgMarkDic.Add("Length", "J");
            //msgMarkDic.Add("ByteOrder", "K");
            //msgMarkDic.Add("ValueType", "L");
            //msgMarkDic.Add("InitialValue", "M");
            //msgMarkDic.Add("Factor", "N");
            //msgMarkDic.Add("Offset", "O");
            //msgMarkDic.Add("Unit", "P");
            //msgMarkDic.Add("Minimum", "Q");
            //msgMarkDic.Add("Maximum", "R");
            //msgMarkDic.Add("ValueTable", "S");
        }

        public void GenDBCFile(string filepath)
        {

            string strTest = "";
            strTest = DBC_Templete; 

            string msgstr = "";
            foreach (var item in listMsgStr)
            {
                msgstr = msgstr + item+"\n";
            }
            string commantstr = "";
            foreach (var item in listCommantStr)
            {
                commantstr = commantstr + item;
            }

            string cycletimestr = "";
            foreach (var item in listCyclTimeStr)
            {
                cycletimestr = cycletimestr + item;
            }
            string valuetablestr = "";
            foreach (var item in listValStr)
            {
                valuetablestr = valuetablestr + item;
            }
            strTest = DBC_Header_Templete + "\n" + NodeStr + "\n" + msgstr + commantstr +  valuetablestr;
            File.WriteAllText(filepath, strTest, Encoding.UTF8);

        }
        private void GetMsg()
        {
            
        }
    }
}
