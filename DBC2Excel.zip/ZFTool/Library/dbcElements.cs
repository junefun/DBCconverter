﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBC2Excel
{
    class dbcElements
    {

    }

    public  class DBCAnalysis
    {
        Dictionary<string, string> gDic;
        public List<Message> lisMsg { get; set; }
        public string readLine { get; set; }
        ExcelBase excelsave;
        ExcelBE besave;
        public DBCAnalysis()
        {
            lisMsg = new List<Message>();
            
            gDic = new Dictionary<string, string>();
            gDic.Add("0", "Motorola");
            gDic.Add("1", "Intel");
            gDic.Add("+", "Unsigned");
            gDic.Add("-", "Signed");
        }
        public void OpenExcelTeplete()
        {
             excelsave = new ExcelBase(Environment.CurrentDirectory + "\\dbcTemplete0416.xlsx", 1);
            //creates the main header
             besave = null;
        }
        public void SaveExcel(string path)
        {
            excelsave.saveExcel(path);
            excelsave.CloseExcel();
        }
        public int InsertMsg(int i,int signalnum)
        {
            besave = new ExcelBE(3 + i + signalnum, 1, lisMsg[i].MsgID, "A" + (3 + i + signalnum).ToString(), "A" + (3 + i + signalnum).ToString(), "YELLOW", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 2, lisMsg[i].MsgName, "B" + (3 + i + signalnum).ToString(), "B" + (3 + i + signalnum).ToString(), "YELLOW", true, 30, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 3, lisMsg[i].MsgType, "C" + (3 + i + signalnum).ToString(), "C" + (3 + i + signalnum).ToString(), "YELLOW", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 4, lisMsg[i].Cycletime, "D" + (3 + i + signalnum).ToString(), "D" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 5, lisMsg[i].SendType, "E" + (3 + i + signalnum).ToString(), "E" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 6, lisMsg[i].Delaytime, "F" + (3 + i + signalnum).ToString(), "F" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 7, lisMsg[i].DLC, "G" + (3 + i + signalnum).ToString(), "G" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 20, lisMsg[i].Transmiter, "T" + (3 + i + signalnum).ToString(), "T" + (3 + i + signalnum).ToString(), "YELLOW", true, 30, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 21, lisMsg[i].Receiver, "U" + (3 + i + signalnum).ToString(), "U" + (3 + i + signalnum).ToString(), "YELLOW", true, 40, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 22, lisMsg[i].Commants, "V" + (3 + i + signalnum).ToString(), "V" + (3 + i + signalnum).ToString(), "YELLOW", true, 50, "n", null);
            excelsave.InsertData(besave);

            return signalnum;
        }
        public int InsertSignal(int i, int signalnum,int j)
        {
            besave = new ExcelBE(4 + i + signalnum, 8, lisMsg[i].Signals[j].SigName, "H" + (4 + i + signalnum).ToString(), "H" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 9, lisMsg[i].Signals[j].StartBit, "I" + (4 + i + signalnum).ToString(), "I" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 10, lisMsg[i].Signals[j].Length, "J" + (4 + i + signalnum).ToString(), "J" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 11, lisMsg[i].Signals[j].ByteOrder, "K" + (4 + i + signalnum).ToString(), "K" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 12, lisMsg[i].Signals[j].ValueType, "L" + (4 + i + signalnum).ToString(), "L" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 13, lisMsg[i].Signals[j].InitialValue, "M" + (4 + i + signalnum).ToString(), "M" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 14, lisMsg[i].Signals[j].Factor, "N" + (4 + i + signalnum).ToString(), "N" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 15, lisMsg[i].Signals[j].Offset, "O" + (4 + i + signalnum).ToString(), "O" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 16, lisMsg[i].Signals[j].Unit, "P" + (4 + i + signalnum).ToString(), "P" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 17, lisMsg[i].Signals[j].Minimum, "Q" + (4 + i + signalnum).ToString(), "Q" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 18, lisMsg[i].Signals[j].Maximum, "R" + (4 + i + signalnum).ToString(), "R" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 19, lisMsg[i].Signals[j].ValueTable, "S" + (4 + i + signalnum).ToString(), "S" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 21, lisMsg[i].Signals[j].Receiver, "U" + (4 + i + signalnum).ToString(), "U" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(4 + i + signalnum, 22, lisMsg[i].Signals[j].Commants, "V" + (4 + i + signalnum).ToString(), "V" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
            excelsave.InsertData(besave);

            signalnum++;

            return signalnum;
        }
        public int InsertRow(int i ,int signalnum)
        {
            besave = new ExcelBE(3 + i + signalnum, 1, lisMsg[i].MsgID, "A" + (3 + i + signalnum).ToString(), "A" + (3 + i + signalnum).ToString(), "YELLOW", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 2, lisMsg[i].MsgName, "B" + (3 + i + signalnum).ToString(), "B" + (3 + i + signalnum).ToString(), "YELLOW", true, 30, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 3, lisMsg[i].MsgType, "C" + (3 + i + signalnum).ToString(), "C" + (3 + i + signalnum).ToString(), "YELLOW", true, 20, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 4, lisMsg[i].Cycletime, "D" + (3 + i + signalnum).ToString(), "D" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 5, lisMsg[i].SendType, "E" + (3 + i + signalnum).ToString(), "E" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 6, lisMsg[i].Delaytime, "F" + (3 + i + signalnum).ToString(), "F" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 7, lisMsg[i].DLC, "G" + (3 + i + signalnum).ToString(), "G" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 20, lisMsg[i].Transmiter, "T" + (3 + i + signalnum).ToString(), "T" + (3 + i + signalnum).ToString(), "YELLOW", true, 30, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 21, lisMsg[i].Receiver, "U" + (3 + i + signalnum).ToString(), "U" + (3 + i + signalnum).ToString(), "YELLOW", true, 40, "n", null);
            excelsave.InsertData(besave);
            besave = new ExcelBE(3 + i + signalnum, 22, lisMsg[i].Commants, "V" + (3 + i + signalnum).ToString(), "V" + (3 + i + signalnum).ToString(), "YELLOW", true, 50, "n", null);
            excelsave.InsertData(besave);
            for (int j = 0; j < lisMsg[i].Signals.Count; j++)
            {
                besave = new ExcelBE(4 + i + signalnum, 8, lisMsg[i].Signals[j].SigName, "H" + (4 + i + signalnum).ToString(), "H" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 9, lisMsg[i].Signals[j].StartBit, "I" + (4 + i + signalnum).ToString(), "I" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 10, lisMsg[i].Signals[j].Length, "J" + (4 + i + signalnum).ToString(), "J" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 11, lisMsg[i].Signals[j].ByteOrder, "K" + (4 + i + signalnum).ToString(), "K" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 12, lisMsg[i].Signals[j].ValueType, "L" + (4 + i + signalnum).ToString(), "L" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 13, lisMsg[i].Signals[j].InitialValue, "M" + (4 + i + signalnum).ToString(), "M" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 14, lisMsg[i].Signals[j].Factor, "N" + (4 + i + signalnum).ToString(), "N" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 15, lisMsg[i].Signals[j].Offset, "O" + (4 + i + signalnum).ToString(), "O" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 16, lisMsg[i].Signals[j].Unit, "P" + (4 + i + signalnum).ToString(), "P" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 17, lisMsg[i].Signals[j].Minimum, "Q" + (4 + i + signalnum).ToString(), "Q" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 18, lisMsg[i].Signals[j].Maximum, "R" + (4 + i + signalnum).ToString(), "R" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 19, lisMsg[i].Signals[j].ValueTable, "S" + (4 + i + signalnum).ToString(), "S" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 21, lisMsg[i].Signals[j].Receiver, "U" + (4 + i + signalnum).ToString(), "U" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                excelsave.InsertData(besave);
                besave = new ExcelBE(4 + i + signalnum, 22, lisMsg[i].Signals[j].Commants, "V" + (4 + i + signalnum).ToString(), "V" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                excelsave.InsertData(besave);

                signalnum++;
            }
            return signalnum;
        }
      
        public void ExcelGen(string savepath)
        {
            ExcelBase excel = new ExcelBase(Environment.CurrentDirectory+ "\\dbcTemplete0416.xlsx", 1);
            //creates the main header
            ExcelBE be = null;

            int signalnum = 0;
            for (int i = 0; i < lisMsg.Count; i++)
            {
                be = new ExcelBE(3 + i + signalnum, 1, lisMsg[i].MsgID, "A" + (3 + i + signalnum).ToString(), "A" + (3 + i + signalnum).ToString(), "YELLOW", true, 20, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 2, lisMsg[i].MsgName, "B" + (3 + i + signalnum).ToString(), "B" + (3 + i + signalnum).ToString(), "YELLOW", true, 30, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 3, lisMsg[i].MsgType, "C" + (3 + i + signalnum).ToString(), "C" + (3 + i + signalnum).ToString(), "YELLOW", true, 20, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 4, lisMsg[i].Cycletime, "D" + (3 + i + signalnum).ToString(), "D" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 5, lisMsg[i].SendType, "E" + (3 + i + signalnum).ToString(), "E" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 6, lisMsg[i].Delaytime, "F" + (3 + i + signalnum).ToString(), "F" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 7, lisMsg[i].DLC, "G" + (3 + i + signalnum).ToString(), "G" + (3 + i + signalnum).ToString(), "YELLOW", true, 10, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 20, lisMsg[i].Transmiter, "T" + (3 + i + signalnum).ToString(), "T" + (3 + i + signalnum).ToString(), "YELLOW", true, 30, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 21, lisMsg[i].Receiver, "U" + (3 + i + signalnum).ToString(), "U" + (3 + i + signalnum).ToString(), "YELLOW", true, 40, "n", null);
                excel.InsertData(be);
                be = new ExcelBE(3 + i + signalnum, 22, lisMsg[i].Commants, "V" + (3 + i + signalnum).ToString(), "V" + (3 + i + signalnum).ToString(), "YELLOW", true, 50, "n", null);
                excel.InsertData(be);
                for (int j = 0; j < lisMsg[i].Signals.Count; j++)
                {
                    be = new ExcelBE(4 + i + signalnum, 8, lisMsg[i].Signals[j].SigName, "H" + (4 + i + signalnum).ToString(), "H" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 9, lisMsg[i].Signals[j].StartBit, "I" + (4 + i + signalnum).ToString(), "I" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 10, lisMsg[i].Signals[j].Length, "J" + (4 + i + signalnum).ToString(), "J" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 11, lisMsg[i].Signals[j].ByteOrder, "K" + (4 + i + signalnum).ToString(), "K" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 12, lisMsg[i].Signals[j].ValueType, "L" + (4 + i + signalnum).ToString(), "L" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 13, lisMsg[i].Signals[j].InitialValue, "M" + (4 + i + signalnum).ToString(), "M" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 14, lisMsg[i].Signals[j].Factor, "N" + (4 + i + signalnum).ToString(), "N" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 15, lisMsg[i].Signals[j].Offset, "O" + (4 + i + signalnum).ToString(), "O" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 16, lisMsg[i].Signals[j].Unit, "P" + (4 + i + signalnum).ToString(), "P" + (4 + i + signalnum).ToString(), "PeachPuff", true, 10, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 17, lisMsg[i].Signals[j].Minimum, "Q" + (4 + i + signalnum).ToString(), "Q" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 18, lisMsg[i].Signals[j].Maximum, "R" + (4 + i + signalnum).ToString(), "R" + (4 + i + signalnum).ToString(), "PeachPuff", true, 20, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 19, lisMsg[i].Signals[j].ValueTable, "S" + (4 + i + signalnum).ToString(), "S" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 21, lisMsg[i].Signals[j].Receiver, "U" + (4 + i + signalnum).ToString(), "U" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                    excel.InsertData(be);
                    be = new ExcelBE(4 + i + signalnum, 22, lisMsg[i].Signals[j].Commants, "V" + (4 + i + signalnum).ToString(), "V" + (4 + i + signalnum).ToString(), "PeachPuff", true, 30, "n", null);
                    excel.InsertData(be);

                    signalnum++;
                }

            }


            excel.saveExcel(savepath);
            excel.CloseExcel();
        }

        public void ReadDBC(String filepath)
        {
            StreamReader SR = new StreamReader(filepath, Encoding.UTF8);
            string temp;
            string cmtemp = "";
            int cmmark = 0;
            while ((temp = SR.ReadLine()) != null)
            {
                readLine = temp;
                
                if(!temp.StartsWith("  "))
                {
                    if (temp.StartsWith("CM_")|| temp.StartsWith("VAL_"))
                     {        
                        cmmark = 1;
                    }
                    if (cmmark == 1)
                    {
                        cmtemp = cmtemp + temp;
                    }
                    if (temp.EndsWith("\";")|| temp.EndsWith("\" ;"))
                    {
                        cmmark = 0;
                        DBCAnalysis1(cmtemp, "", "");
                        cmtemp = "";
                    }
                    else if (!temp.StartsWith("CM_")&& !temp.StartsWith("VAL_"))
                    {
                        DBCAnalysis1(temp, "", "");
                    }
                }

               
                
                
            }
        }

        public void DBCAnalysis1(string arg1, string arg2, string arg3)
        {
            string temp = arg1.Trim();
            if (temp.StartsWith("BO_ "))
            {
                MsgAnalysis(temp);
            }
            else if (temp.StartsWith("SG_ "))
            {
                SigAnalysis(temp, "", "");
            }
            else if (temp.StartsWith("VAL_ "))
            {
                ValueTableAnalysis(temp);
            }
            else if (temp.StartsWith("CM_ "))
            {
                CommentAnalysis(temp);
            }
            else if (temp.StartsWith("BA_ "))
            {
                CycleAnalysis(temp);

            }
        }

        public void CommentAnalysis(string arg1)
        {
            //try
            //{

                string[] temp = arg1.Split(' ');
                
                if (temp[1] == "BO_")
                {
                    int indexmsg = lisMsg.FindIndex(delegate (Message msg)
                                         {
                                             if (temp[2] != "3221225472")
                                             {
                                                 return msg.MsgID == Convert.ToUInt32(temp[2]).ToString("X2");
                                             }
                                             else
                                             {
                                                 return msg.MsgID == "FFFFFFFF";
                                             }
                                             
                                         }
                                        );

                    lisMsg[indexmsg].Commants = arg1.Split('\"')[1];
                }
                else if (temp[1] == "SG_")
                {
                    int indexmsg = lisMsg.FindIndex(delegate (Message msg)
                     {
                         if (temp[2] != "3221225472")
                         {
                             return msg.MsgID == Convert.ToUInt32(temp[2]).ToString("X2");
                         }
                         else
                         {
                             return msg.MsgID == "FFFFFFFF";
                         }
                        // return msg.MsgID == Convert.ToInt32(temp[2]).ToString("X2") ;
                     }
                     );

                    int indexsig = lisMsg[indexmsg].Signals.FindIndex(delegate (Signal sig)
                      {
                          if (sig.SigName == temp[3].Trim())
                             {
                              return true;
                          }
                          else if(sig.SigName.Contains(temp[3].Trim()))
                          {
                              return true;
                          }
                          else
                          {
                              return false;
                          }

                      });
                string[] sss = arg1.Split('\"');
                if (indexmsg >= 0)
                {
                    lisMsg[indexmsg].Signals[indexsig].Commants = sss[1];
                }
                    
                }
            //}
            //catch (Exception ex)
            //{
            //    throw;
            //}
        }

        public void ValueTableAnalysis(string arg1)
        {
           // try
            //{

                string[] temp = arg1.Split(' ');

                    int indexmsg = lisMsg.FindIndex(delegate (Message msg)
                    {
                        if (temp[1] != "3221225472")
                        {
                            return msg.MsgID == Convert.ToUInt32(temp[1]).ToString("X2");
                        }
                        else
                        {
                            return msg.MsgID == "FFFFFFFF";
                        }
                        //return msg.MsgID == Convert.ToInt32(temp[1]).ToString("X2") ;
                    }
                     );

                    int indexsig = lisMsg[indexmsg].Signals.FindIndex(delegate (Signal sig)
                    {
                        if (sig.SigName == temp[2].Trim())
                        {
                            return true;
                        }
                        else if (sig.SigName.Contains(temp[2].Trim()))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                        
                    });
            
            lisMsg[indexmsg].Signals[indexsig].ValueTable = arg1.Replace(temp[0].Trim() + " " + temp[1].Trim() + " " + temp[2].Trim() + " ", "");
           // }
            //catch (Exception ex)
            //{
             //   throw;
           // }
        }

        public void CycleAnalysis(string arg1)
        {
           // try
           // {

                string[] temp = arg1.Split(' ');

                if (temp[1].Trim() == "\"GenMsgCycleTime\""|| temp[1] == "\"GenMsgSendType\"" || temp[1] == "\"GenMsgDelayTime\"")
                {
                    int indexmsg = lisMsg.FindIndex(delegate (Message msg)
                    {
                        if (temp[3].Trim() != "3221225472")
                        {
                            return msg.MsgID == Convert.ToUInt32(temp[3]).ToString("X2");
                        }
                        else
                        {
                            return msg.MsgID == "FFFFFFFF";
                        }
                        //return msg.MsgID == Convert.ToInt32(temp[3]).ToString("X2")|| msg.MsgID=="FFFFFFFF";
                    }

                 );
                if (temp[1].Trim() == "\"GenMsgCycleTime\"")
                {
                    lisMsg[indexmsg].Cycletime = temp[4].Replace(";", "");
                }

                else if (temp[1].Trim() == "\"GenMsgSendType\"")
                {
                    lisMsg[indexmsg].SendType = temp[4].Replace(";", "");
                }
                else
                {
                    lisMsg[indexmsg].Delaytime = temp[4].Replace(";", "");
                }
                    
                }

                
            //}
            //catch (Exception ex)
            //{
            //    throw;
            //}
        }
        public Signal SigAnalysis(string sigstr, string sigcm, string sigval)
        {
            Signal s = new Signal();
            string temp = sigstr.Replace("SG_ ", "").Replace(":", "*")
                                .Replace("@", "*").Replace("(", "*").Replace(") [", "*").Replace("] \"", " *").Replace("] \"", " *").Replace("\" ", " *");

            string[] arystr = temp.Split('*');


            s.SigName = arystr[0].Trim();
            s.StartBit = arystr[1].Trim().Split('|')[0];
            s.Length = arystr[1].Trim().Split('|')[1];
            s.ByteOrder = gDic[arystr[2].Substring(0, 1)];
            s.ValueType = gDic[arystr[2].Substring(1, 1)];
            s.InitialValue = "0";
            s.Factor = arystr[3].Split(',')[0];
            s.Offset = arystr[3].Split(',')[1];
            s.Minimum = arystr[4].Split('|')[0];
            s.Maximum = arystr[4].Split('|')[1];
            s.Unit = arystr[5];
            s.Receiver = arystr[6];
            s.ValueTable = sigval;
            s.Commants = sigcm;
            lisMsg[lisMsg.Count - 1].Signals.Add(s);
            return s;
        }

        public Message MsgAnalysis(string msgstr)
        {
            Message m=new Message();
            string temp = msgstr.Replace("BO_ ", "").Replace(" ", "*");
            string[] arystr = temp.Split('*');
            if (arystr[0] == "3221225472")
            {
                m.MsgID = "FFFFFFFF";
            }
            else
            {
                m.MsgID = Convert.ToUInt32(arystr[0]).ToString("X2");
            }
            
            m.MsgName = arystr[1].Replace(":","");
            m.DLC = arystr[2];
            
            m.Transmiter = arystr[3];
            m.Signals = new List<Signal>();
            lisMsg.Add(m);
            

            return m;
        }
    }
    public class Message
    {
        public string MsgID { get; set; }
        public string MsgName { get; set; }
        public string MsgType { get; set; }
        public string Cycletime { get; set;}
        public string Delaytime { get; set; }
        public string SendType { get; set; }
        public string DLC { get; set;}
        public string Transmiter { get; set; }
        public string Receiver { get; set; }
        public string Commants { get; set; }
        public List<Signal> Signals { get; set; }

        public Message()
        {
            MsgID = "0x0";
            DLC = "8";
            MsgType = "CAN Standard";
            SendType = "0";
            Delaytime = "5";
        }
    }

    public class Signal
    {
        public string SigName { get; set; }
        public string StartBit { get; set; }
        public string Length { get; set; }
        public string ByteOrder { get; set; }
        public string ValueType { get; set; }
        public string InitialValue { get; set; }
        public string Factor { get; set; }
        public string Offset { get; set; }

        public string Minimum { get; set; }
        public string Maximum { get; set; }
        public string Transmiter { get; set; }
        public string Receiver { get; set; }
        public string Commants { get; set; }
        public string ValueTable {get; set; }
        public string Unit { get; set; }
        public Signal()
        {
            Length = "8";
            ByteOrder = "Intel";
            ValueType = "Signed";
            InitialValue = "0";
            Factor = "0";
            Offset = "0";
            Minimum = "0";
            Maximum = "0";
            Unit = "bit";
            
        }

    }

}
