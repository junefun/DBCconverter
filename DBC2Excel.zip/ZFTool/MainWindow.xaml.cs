﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZFTool
{


    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("aa");
        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            int aaa = listmsg.SelectedIndex;
            MessageBox.Show(aaa.ToString());
        }

        private void TextBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
           
        }

        private void Listmsg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!select.Text.Contains(listmsg.SelectedIndex.ToString()))
            {
                if (select.Text == "")
                {
                    select.Text = select.Text + listmsg.SelectedIndex.ToString();
                }
                else
                {
                    select.Text = select.Text + "," + listmsg.SelectedIndex.ToString();
                }
                
            }
        }

        private void Select_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
