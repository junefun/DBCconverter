﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ZFTool.Model;
using DBC2Excel;
using Microsoft.Win32;
using System.ComponentModel;
using System.IO;
using System.Text;
using System;

namespace ZFTool
{

   public class ListColumnTag
    {
        private string coloumnname;

        public string ColName
        {
            get { return coloumnname; }
            set { coloumnname = value; }
        }
        private string tag;

        public string ColTag
        {
            get { return tag; }
            set { tag = value; }
        }

    }


    public class MainViewModel:ViewModelBase
    {
        private string codetemplete_header = "//*********************************\n// MESSAGENAME MESSAGEID\n//*********************************\n";
        private string codetemplete_body1 = "TxMsg.Id   = MESSAGEID;\n	TxMsg.Type = MESSAGETYPE;\nTxMsg.Len  = MESSAGELEN;\nTxMsg.Data32[0]	= 0;\nTxMsg.Data32[1]	= 0;\n";
        private string codetemplete_body2 = "Write_CAN_signal_U32(SIGNALNAME, TxMsg.Data8, MESSAGEORDER, STARTBIT, SIGLEN); \n";
        private string codetemplete_body3 = "CAN_UserWrite(CANNUMBER, &TxMsg);\n";
        private readonly IDataService _dataService;

        public ICommand testCommand { get; set; }

        private List<ListColumnTag> listtag;

        public List<ListColumnTag> ListTag
        {
            get { return listtag; }
            set { Set(ref listtag, value); }
        }

        private string _mark;

        public string Mark
        {
            get { return _mark; }
            set {Set(ref _mark , value); }
        }
        private List<Message> _listMsg;

        public List<Message> ListMsg
        {
            get { return _listMsg; }
            set { Set(ref _listMsg , value); }
        }
        private string _canname;

        public string CanName
        {
            get { return _canname; }
            set {Set(ref _canname , value); }
        }
        private string _Listselected;

        public string ListSelected
        {
            get { return _Listselected; }
            set {Set(ref _Listselected , value); }
        }

        Excel2DBC ex2dbc;
        DBCAnalysis dba;
        private string dbcpath;
        private BackgroundWorker bw = new BackgroundWorker();

        public string DBCPath
        {
            get { return dbcpath; }
            set { Set(ref dbcpath , value); }
        }

        private string _RunningStatus;

        public string RunningStatus
        {
            get { return _RunningStatus; }
            set { Set(ref _RunningStatus , value); }
        }
        private double _Progressbar;

        public double Progressbar
        {
            get { return _Progressbar; }
            set {Set(ref _Progressbar , value); }
        }
        private string _savepath;

        public string Savepath
        {
            get { return _savepath; }
            set {Set(ref _savepath , value); }
        }
        private string _savedbcpath;
        public string SaveDBCpath
        {
            get { return _savedbcpath; }
            set { Set(ref _savedbcpath, value); }
        }

        private string _ExcelPath;
        public string ExcelPath
        {
            get { return _ExcelPath; }
            set { Set(ref _ExcelPath, value); }
        }

        private string _DBCcontent;
        public string DBCcontent
        {
            get { return _DBCcontent; }
            set { Set(ref _DBCcontent, value); }
        }
        private bool _ProgressVisable;

        public bool ProgressVisable
        {
            get { return _ProgressVisable; }
            set {Set(ref _ProgressVisable , value); }
        }

        private string _listboxselectedIndex;

        public string listboxselectedIndex
        {
            get { return _listboxselectedIndex; }
            set { Set(ref _listboxselectedIndex , value); }
        }

        public int RowsCount { get; set; }
        public ICommand LoadDBC { get; set; }
        public ICommand GenExcel { get; set; }
        public ICommand OpenExcel { get; set; }
        public ICommand LoadExcel { get; set; }
        public ICommand GenDBC { get; set; }
        public ICommand OpenDBC { get; set; }
        public ICommand IsCheckbox { get; set; }
        public ICommand LoadDBCc { get; set; }
        public ICommand TextChange { get; set; }
        public int JOBtAG { get; set; }
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel(IDataService dataService)
        {
            
            _dataService = dataService;
            _dataService.GetData(
                (item, error) =>
                {
                    if (error != null)
                    {
                        // Report error here
                        return;
                    }

                });

            IsCheckbox = new RelayCommand(IsChecked);
            testCommand = new RelayCommand(testCommandM);
            LoadDBC = new RelayCommand(LoadDBCEx);
            GenExcel = new RelayCommand(GenarateExcelEx);
            OpenExcel = new RelayCommand(OpenExcelEX);
            LoadExcel = new RelayCommand(LoadExcelEx);
            GenDBC = new RelayCommand(GenarateDBCEx);
            OpenDBC = new RelayCommand(OpenDBCEX);
            ListTag = new List<ListColumnTag>();
            ListMsg = new List<Message>();
            ListTag.Add(new ListColumnTag() { ColName = "MsgID", ColTag = "A" });
            ListTag.Add(new ListColumnTag() { ColName = "MsgName", ColTag = "B" });
            ListTag.Add(new ListColumnTag() { ColName = "MsgType", ColTag = "C" });
            ListTag.Add(new ListColumnTag() { ColName = "Cycletime", ColTag = "D" });
            ListTag.Add(new ListColumnTag() { ColName = "Delaytime", ColTag = "F" });
            ListTag.Add(new ListColumnTag() { ColName = "SendType", ColTag = "E" });
            ListTag.Add(new ListColumnTag() { ColName = "DLC", ColTag = "G" });
            ListTag.Add(new ListColumnTag() { ColName = "Transmiter", ColTag = "T" });
            ListTag.Add(new ListColumnTag() { ColName = "Receiver", ColTag = "U" });
            ListTag.Add(new ListColumnTag() { ColName = "Commants", ColTag = "V" });
            ListTag.Add(new ListColumnTag() { ColName = "SigName", ColTag = "H" });
            ListTag.Add(new ListColumnTag() { ColName = "StartBit", ColTag = "I" });
            ListTag.Add(new ListColumnTag() { ColName = "Length", ColTag = "J" });
            ListTag.Add(new ListColumnTag() { ColName = "ByteOrder", ColTag = "K" });
            ListTag.Add(new ListColumnTag() { ColName = "ValueType", ColTag = "L" });
            ListTag.Add(new ListColumnTag() { ColName = "InitialValue", ColTag = "M" });
            ListTag.Add(new ListColumnTag() { ColName = "Factor", ColTag = "N" });
            ListTag.Add(new ListColumnTag() { ColName = "Offset", ColTag = "O" });
            ListTag.Add(new ListColumnTag() { ColName = "Unit", ColTag = "P" });
            ListTag.Add(new ListColumnTag() { ColName = "Minimum", ColTag = "Q" });
            ListTag.Add(new ListColumnTag() { ColName = "Maximum", ColTag = "R" });
            ListTag.Add(new ListColumnTag() { ColName = "ValueTable", ColTag = "S" });
            Mark = "false";
            ex2dbc = new Excel2DBC();
            dba = new DBCAnalysis();
            CanName = "CAN_BUS4";
            

            //后台工作初始化
            bw.WorkerReportsProgress = true;//报告进度
            bw.WorkerSupportsCancellation = true;//支持取消
            bw.DoWork += new DoWorkEventHandler(bgWorker_DoWork);//开始工作
            bw.ProgressChanged += new ProgressChangedEventHandler(bgWorker_ProgessChanged);//进度改变事件
            bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bgWorker_WorkerCompleted);//进度完成事件
            JOBtAG = 0;

            LoadDBCc = new RelayCommand(LoadDBCcEX);
        }

        private void IsChecked()
        {
            Mark = listboxselectedIndex.ToString(); ;
        }


        private void TextChangeEX()
        {
            try
            {

            }
            catch (Exception ex )
            {

                throw ex;
            }
            
            if (DBCPath != null && DBCPath.EndsWith(".dbc"))
            {

                string aa = "";
                dba.ReadDBC(DBCPath);
                ListMsg = dba.lisMsg;
                foreach (var item in ListMsg)
                {
                    aa = aa + (codetemplete_header + codetemplete_body1).Replace("MESSAGENAME", item.MsgName)
                        .Replace("MESSAGEID", "0x" + item.MsgID).Replace("MESSAGETYPE", "CAN_MSG_STANDARD")
                        .Replace("MESSAGELEN", item.DLC);
                    foreach (var i in item.Signals)
                    {
                        aa = aa + codetemplete_body2.Replace("SIGNALNAME", i.SigName).Replace("MESSAGEORDER", i.ByteOrder)
                            .Replace("STARTBIT", i.StartBit).Replace("SIGLEN", i.Length);
                    }
                    aa = aa + codetemplete_body3.Replace("CANNUMBER", CanName);

                }

                Mark = aa;

            }
            else
            {
                Mark = "error dbc file path!";
            }
        }
        private void LoadDBCcEX()
        {
            LoadDBCEx();

            if (DBCPath != null && DBCPath.EndsWith(".dbc"))
            {

                string aa = "";
                dba.ReadDBC(DBCPath);
                ListMsg = dba.lisMsg;
                foreach (var item in ListMsg)
                {
                    aa = aa + (codetemplete_header + codetemplete_body1).Replace("MESSAGENAME", item.MsgName)
                        .Replace("MESSAGEID", "0x" + item.MsgID).Replace("MESSAGETYPE", "CAN_MSG_STANDARD")
                        .Replace("MESSAGELEN", item.DLC);
                    foreach (var i in item.Signals)
                    {
                        aa = aa + codetemplete_body2.Replace("SIGNALNAME", i.SigName).Replace("MESSAGEORDER", i.ByteOrder)
                            .Replace("STARTBIT",i.StartBit).Replace("SIGLEN", i.Length);
                    }
                    aa = aa + codetemplete_body3.Replace("CANNUMBER", CanName);
                       
                }

                Mark = aa;

            }
            else
            {
                Mark = "error dbc file path!";
            }
        }

        private void OpenExcelEX()
        {
            if (Savepath != null && Savepath.EndsWith(".xlsx"))
            {
                ExcelBase EX = new ExcelBase();
                EX.openExcel(Savepath, true);
            }
            else
            {
                RunningStatus = "error file path";
            }
        }

        private void OpenDBCEX()
        {
            if (SaveDBCpath != null && SaveDBCpath.EndsWith(".dbc"))
            {
                StreamReader SR = new StreamReader(SaveDBCpath, Encoding.UTF8);
                string temp;
                string DBCcontent = "";

                while ((temp = SR.ReadLine()) != null)
                {
                    DBCcontent = DBCcontent + temp + "\n";
                }
                Mark = DBCcontent;
            }
            else
            {
                RunningStatus = "error file path";
            }
        }

        private void LoadDBCEx()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            //openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "dbc file|*.dbc";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == true)
            {
                DBCPath = openFileDialog.FileName;  
            }
        }

        private void LoadExcelEx()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            //openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "excel file|*.xlsx";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == true)
            {
                ExcelPath = openFileDialog.FileName;
            }
        }

        private void GenarateDBCEx()
        {
            if (ExcelPath != null && ExcelPath.EndsWith(".xlsx"))
            {
                SaveFileDialog sfd = new SaveFileDialog();

                sfd.Filter = "dbc file|*.dbc";

                if (sfd.ShowDialog() == true)
                {
                    testCommandM();
                    
                    SaveDBCpath = sfd.FileName;
                    //后台工作运行中，避免重入
                    if (bw.IsBusy) return;
                    JOBtAG = 1;
                    bw.RunWorkerAsync();//触发DoWork事件并异步执行，IsBusy置为True


                }
                else
                {

                }
                
            }
            else
            {
                Mark = "error dbc file path!";
            }

        }

        private void GenarateExcelEx()
        {
           if(DBCPath!=null&& DBCPath.EndsWith(".dbc"))
            {
                SaveFileDialog sfd = new SaveFileDialog();

                sfd.Filter = "excel|*.xlsx";

                if (sfd.ShowDialog() == true)
                {

                    dba.ReadDBC(DBCPath);
                    RowsCount = dba.lisMsg.Count;
                    foreach (var item in dba.lisMsg)
                    {
                        RowsCount = RowsCount + item.Signals.Count;
                    }
                    Savepath = sfd.FileName;

                    //后台工作运行中，避免重入
                    if (bw.IsBusy) return;
                    JOBtAG = 2;
                    bw.RunWorkerAsync();//触发DoWork事件并异步执行，IsBusy置为True
                    
                   
                }
                else
                {

                }

            }
           else
            {
                Mark = "error dbc file path!";
            }

        }


        public void bgWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //(string)e.Argument == "参数";

                if (bw.CancellationPending)
                {//用户取消了工作
                    e.Cancel = true;
                    return;
                }
                else
                {
                // bw.ReportProgress(0, "Working");//报告进度，触发ProgressChanged事件
                RunningStatus = "Running";
                ProgressVisable = true;
                if (JOBtAG == 1)
                {
                    ex2dbc.ReadExcel(ExcelPath, "A", "V");
                    Progressbar = 0.4;
                    ex2dbc.NodeGen();
                    Progressbar = 0.6;
                    ex2dbc.MessgaeGen();
                    Progressbar = 0.8;
                    ex2dbc.GenDBCFile(SaveDBCpath);
                    Progressbar = 1;

                }
                else if (JOBtAG == 2)
                {
                    dba.OpenExcelTeplete();
                    int signalnum = 0;
                    for (int i = 0; i < dba.lisMsg.Count; i++)
                    {
                        //bw.ReportProgress(i, "Working");
                        //signalnum = dba.InsertRow(i, signalnum);

                        signalnum = dba.InsertMsg(i, signalnum);
                        bw.ReportProgress(signalnum, "Working");
                        for (int j = dba.lisMsg[i].Signals.Count-1; j >=0; j--)
                        {
                            signalnum = dba.InsertSignal(i, signalnum,j);
                            bw.ReportProgress(signalnum, "Working");
                        }


                    }
                    dba.SaveExcel(Savepath);
                    bw.ReportProgress(dba.lisMsg.Count, "Working");

                }
                else
                { }
                ProgressVisable = false;
                RunningStatus = "Complete!";
            }

        }
        //进度改变事件
        public void bgWorker_ProgessChanged(object sender, ProgressChangedEventArgs e)
        {
            //(string)e.UserState=="Working"
            Progressbar = ((double)e.ProgressPercentage / (double)RowsCount);//取得进度更新控件，不用Invoke了
        }
        //后台工作执行完毕,IsBusy置为False
        public void bgWorker_WorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //e.Error == null 是否发生错误
            //e.Cancelled 完成是由于取消还是正常完成
        }


        private void testCommandM()
        {
            ex2dbc.msgMarkDic.Clear();
            foreach (var item in ListTag)
            {
                
                ex2dbc.GenDic(item.ColName,item.ColTag);
            }
           
            Mark = "true";
        }

        private string showtext;

        public string ShowText
        {
            get { return showtext; }
            set { Set(ref showtext, value); }
        }


    }
}
